<?php

add_action('init', 'handle_custom_registration');
function handle_custom_registration() {
    // بررسی nonce
    if (isset($_POST['register_user']) && isset($_POST['user_registration_nonce'])) {
        if (!wp_verify_nonce($_POST['user_registration_nonce'], 'user_registration_nonce_action')) {
            die('دسترسی غیرمجاز'); // جلوگیری از ارسال داده‌های غیرمعتبر
        }

        // گرفتن داده‌های فرم
        $billing_first_name = sanitize_text_field( $_POST['billing_first_name'] );
        $billing_last_name = sanitize_text_field( $_POST['billing_last_name'] );
        $billing_city = sanitize_text_field( $_POST['billing_city'] );
        $billing_phone = sanitize_text_field( $_POST['billing_phone'] );
        $billing_email = sanitize_email( $_POST['billing_email'] );
        
        $linkdien_id = sanitize_text_field( $_POST['linkdien_id'] );
        $role_user = sanitize_text_field( $_POST['role_user'] );
        $country_user = sanitize_text_field( $_POST['country_user'] );

        // گرفتن رمز عبور و تایید آن
        $password = sanitize_text_field( $_POST['password'] );
        $confirm_password = sanitize_text_field( $_POST['confirm_password'] );

        // بررسی تطابق رمز عبور
        if ($password !== $confirm_password) {
            echo "رمز عبور و تایید رمز عبور یکسان نیستند.";
            return;
        }

        // ایجاد کاربر جدید با ایمیل و رمز عبور
        $user_id = wp_create_user( $billing_email, $password, $billing_email );

        if (is_wp_error($user_id)) {
            echo "خطا در ایجاد حساب کاربری";
            return;
        }

        // ذخیره متادیتای سفارشی
        update_user_meta($user_id, 'linkdien_id', $linkdien_id);
        update_user_meta($user_id, 'role_user', $role_user);
        update_user_meta($user_id, 'country_user', $country_user);

        // ذخیره فیلدهای billing
        update_user_meta($user_id, 'billing_first_name', $billing_first_name);
        update_user_meta($user_id, 'billing_last_name', $billing_last_name);
        update_user_meta($user_id, 'billing_city', $billing_city);
        update_user_meta($user_id, 'billing_phone', $billing_phone);
        update_user_meta($user_id, 'billing_email', $billing_email);

        // ورود خودکار کاربر بعد از ثبت‌نام
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
        
        // هدایت به صفحه ویرایش حساب کاربری
        wp_redirect('https://silkroadsic.ir/my-account/edit-account/'); 
        exit();
    }
}



// اضافه کردن فیلدهای سفارشی به فرم ویرایش حساب کاربری
add_action('woocommerce_edit_account_form', 'add_custom_fields_to_account_form');
function add_custom_fields_to_account_form() {
    $user_id = get_current_user_id();
    
    // دریافت اطلاعات متادیتا
    $billing_city = get_user_meta($user_id, 'billing_city', true);
    $billing_phone = get_user_meta($user_id, 'billing_phone', true);
    $billing_email = get_user_meta($user_id, 'billing_email', true);
    
    $linkdien_id = get_user_meta($user_id, 'linkdien_id', true);
    $role_user = get_user_meta($user_id, 'role_user', true);
    $country_user = get_user_meta($user_id, 'country_user', true);

    // مقادیر انتخابی برای role_user و country_user
    $role_user_options = array(
        'idea_owner' => 'صاحبان ایده',
        'mentor_coach' => 'منتور و مربی',
        'business_owner' => 'صاحبان کسب و کار',
    );

    $country_user_options = array(
        'iran' => 'ایران',
        'canada' => 'کانادا',
        'uae' => 'امارات',
        'usa' => 'آمریکا',
    );
    ?>

    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="billing_city">شهر <span class="required">*</span></label>
        <input type="text" class="woocommerce-Input input-text" name="billing_city" id="billing_city" value="<?php echo esc_attr($billing_city); ?>" required />
    </p>

    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="billing_phone">شماره موبایل <span class="required">*</span></label>
        <input type="text" class="woocommerce-Input input-text" name="billing_phone" id="billing_phone" value="<?php echo esc_attr($billing_phone); ?>" required />
    </p>

    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="billing_email">ایمیل <span class="required">*</span></label>
        <input type="email" class="woocommerce-Input input-text" name="billing_email" id="billing_email" value="<?php echo esc_attr($billing_email); ?>" required />
    </p>

    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="linkdien_id">آیدی لینکدین <span class="required">*</span></label>
        <input type="text" class="woocommerce-Input input-text" name="linkdien_id" id="linkdien_id" value="<?php echo esc_attr($linkdien_id); ?>" required />
    </p>

    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="role_user">حوزه تخصصی <span class="required">*</span></label>
        <select class="woocommerce-Input input-text" name="role_user" id="role_user" required>
            <?php foreach ($role_user_options as $key => $label): ?>
                <option value="<?php echo esc_attr($key); ?>" <?php selected($role_user, $key); ?>><?php echo esc_html($label); ?></option>
            <?php endforeach; ?>
        </select>
    </p>

    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="country_user">کشور <span class="required">*</span></label>
        <select class="woocommerce-Input input-text" name="country_user" id="country_user" required>
            <?php foreach ($country_user_options as $key => $label): ?>
                <option value="<?php echo esc_attr($key); ?>" <?php selected($country_user, $key); ?>><?php echo esc_html($label); ?></option>
            <?php endforeach; ?>
        </select>
    </p>

    <?php
}

// ذخیره تغییرات فیلدهای سفارشی در پروفایل کاربری ووکامرس
add_action('woocommerce_save_account_details', 'save_custom_fields_in_account');
function save_custom_fields_in_account($user_id) {
    if (isset($_POST['billing_city'])) {
        update_user_meta($user_id, 'billing_city', sanitize_text_field($_POST['billing_city']));
    }
    if (isset($_POST['billing_phone'])) {
        update_user_meta($user_id, 'billing_phone', sanitize_text_field($_POST['billing_phone']));
    }
    if (isset($_POST['billing_email'])) {
        update_user_meta($user_id, 'billing_email', sanitize_email($_POST['billing_email']));
    }

    if (isset($_POST['linkdien_id'])) {
        update_user_meta($user_id, 'linkdien_id', sanitize_text_field($_POST['linkdien_id']));
    }
    if (isset($_POST['role_user'])) {
        update_user_meta($user_id, 'role_user', sanitize_text_field($_POST['role_user']));
    }
    if (isset($_POST['country_user'])) {
        update_user_meta($user_id, 'country_user', sanitize_text_field($_POST['country_user']));
    }
}


add_action('init', 'handle_custom_login');
function handle_custom_login() {
    // بررسی اینکه آیا فرم لاگین ارسال شده است
    if (isset($_POST['login_user'])) {
        $login_username_email = sanitize_text_field($_POST['login_username_email']);
        $login_password = sanitize_text_field($_POST['login_password']);

        // بررسی نام کاربری یا ایمیل
        if (is_email($login_username_email)) {
            $user = get_user_by('email', $login_username_email);
        } else {
            $user = get_user_by('login', $login_username_email);
        }

        // بررسی صحت نام کاربری/ایمیل و رمز عبور
        if ($user && wp_check_password($login_password, $user->user_pass, $user->ID)) {
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID);
            wp_redirect('https://silkroadsic.ir/my-account/');  // هدایت به صفحه خانه بعد از ورود
            exit();
        } else {
            echo '<p style="color:red;">نام کاربری یا رمز عبور اشتباه است.</p>';
        }
    }
}


add_action('edit_user_profile', 'display_custom_user_meta');
add_action('show_user_profile', 'display_custom_user_meta');

function display_custom_user_meta($user) {
    // گرفتن اطلاعات متادیتا
    $role_user = get_user_meta($user->ID, 'role_user', true);
    $country_user = get_user_meta($user->ID, 'country_user', true);
    $linkdien_id = get_user_meta($user->ID, 'linkdien_id', true);

    // نمایش فیلدها
    echo '<h3>اطلاعات اضافی:</h3>';
    echo '<table class="form-table">
            <tr>
                <th><label for="role_user">حوزه تخصصی</label></th>
                <td>
                    <select name="role_user" class="regular-text">
                        <option value="idea_owner" ' . selected($role_user, 'idea_owner', false) . '>صاحبان ایده</option>
                        <option value="mentor_coach" ' . selected($role_user, 'mentor_coach', false) . '>منتور و مربی</option>
                        <option value="business_owner" ' . selected($role_user, 'business_owner', false) . '>صاحبان کسب و کار</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><label for="country_user">کشور</label></th>
                <td>
                    <select name="country_user" class="regular-text">
                        <option value="iran" ' . selected($country_user, 'iran', false) . '>ایران</option>
                        <option value="canada" ' . selected($country_user, 'canada', false) . '>کانادا</option>
                        <option value="uae" ' . selected($country_user, 'uae', false) . '>امارات</option>
                        <option value="usa" ' . selected($country_user, 'usa', false) . '>آمریکا</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><label for="linkdien_id">آیدی لینکدین</label></th>
                <td><input type="text" name="linkdien_id" value="' . esc_attr($linkdien_id) . '" class="regular-text" /></td>
            </tr>
        </table>';
}

// ذخیره تغییرات در متادیتا
add_action('personal_options_update', 'save_custom_user_meta');
add_action('edit_user_profile_update', 'save_custom_user_meta');

function save_custom_user_meta($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    // ذخیره اطلاعات جدید
    if (isset($_POST['role_user'])) {
        update_user_meta($user_id, 'role_user', sanitize_text_field($_POST['role_user']));
    }
    if (isset($_POST['country_user'])) {
        update_user_meta($user_id, 'country_user', sanitize_text_field($_POST['country_user']));
    }
    if (isset($_POST['linkdien_id'])) {
        update_user_meta($user_id, 'linkdien_id', sanitize_text_field($_POST['linkdien_id']));
    }

    // بررسی nonce
    if (!isset($_POST['save_custom_user_meta_nonce']) || 
        !wp_verify_nonce($_POST['save_custom_user_meta_nonce'], 'save_custom_user_meta_nonce_action')) {
        wp_die('متأسفیم، مشکلی در پردازش درخواست شما به وجود آمده است. لطفاً دوباره تلاش کنید');
    }

    // اعتبارسنجی ایمیل
    if (isset($_POST['billing_email'])) {
        $email = sanitize_email($_POST['billing_email']);
        if (!is_email($email)) {
            wp_die('ایمیل وارد شده معتبر نیست.');
        }
        if (email_exists($email) && email_exists($email) != $user_id) {
            wp_die('ایمیل واردشده قبلاً ثبت شده است. لطفاً با ایمیل دیگری ثبت‌نام کنید یا وارد حساب خود شوید.');
        }
        wp_update_user(['ID' => $user_id, 'user_email' => $email]);
    }

    // بررسی شماره موبایل تکراری
    if (isset($_POST['billing_phone'])) {
        $existing_user = get_users([
            'meta_key'   => 'billing_phone',
            'meta_value' => sanitize_text_field($_POST['billing_phone']),
        ]);
        if (!empty($existing_user)) {
            wp_die('شماره موبایل واردشده قبلاً استفاده شده است. لطفاً شماره دیگری وارد کنید.');
        }
    }

    // بررسی رمز عبور و تایید رمز عبور
    if (!empty($_POST['password']) || !empty($_POST['confirm_password'])) {
        if ($_POST['password'] !== $_POST['confirm_password']) {
            wp_die('رمز عبور و تایید آن یکسان نیستند.');
        }
        if (strlen($_POST['password']) < 8) {
            wp_die('رمز عبور باید حداقل ۸ کاراکتر باشد.');
        }
        wp_set_password($_POST['password'], $user_id);
    }

    // اعتبارسنجی لینکدین آیدی
    if (isset($_POST['linkdien_id'])) {
        $linkdien_id = sanitize_text_field($_POST['linkdien_id']);
        if (!preg_match('/^[a-zA-Z0-9_-]{3,16}$/', $linkdien_id)) {
            wp_die('آیدی لینکدین وارد شده معتبر نیست.');
        }
        // بررسی لینکدین آیدی تکراری
        $existing_user = get_users([
            'meta_key'   => 'linkdien_id',
            'meta_value' => $linkdien_id,
        ]);
        if (!empty($existing_user)) {
            wp_die('آیدی لینکدین واردشده قبلاً ثبت شده است. لطفاً آیدی دیگری وارد کنید.');
        }
        update_user_meta($user_id, 'linkdien_id', $linkdien_id);
    }

    // ذخیره دیگر اطلاعات
    if (isset($_POST['role_user'])) {
        update_user_meta($user_id, 'role_user', sanitize_text_field($_POST['role_user']));
    }
    if (isset($_POST['country_user'])) {
        update_user_meta($user_id, 'country_user', sanitize_text_field($_POST['country_user']));
    }
}